function navbar(){

    return ` <div id="first">
    <div id="btn">≡</div>
    <div class="sam">
      <img
        src="https://cdn02.nnnow.com/web-images/master/navtree_metaData/59b2425ae4b0d70964ee66e0/1505806763887/12NNNOWLOGODESKTOP.png"
        width="100%"
        height="100%"
      />
    </div>
    <div class="sam1" style="margin-left: 4%">
      <img src="/images/4.png" width="100%" />
    </div>
    <div class="sam" class="star" style="margin-left: 3%">
      <img src="/images/1.png" />
    </div>
    <div id="broad">Get 10% OFF on a purchase of ₹3000|Code:SEP10</div>
    <div class="sam" class="star" style="margin-right: 3%">
      <img src="/images/1.png" />
    </div>
    <div class="sam" id="get">Get App</div>
    <div class="sam1"><img src="/images/2.png" width="100%" /></div>
    <div class="sam1"><img src="/images/3.png" width="80%" /></div>
  </div>

  <div id="slight">
    <div id="lef">
      <div class="lev" id = "clickBrand" >
        <div >Brands</div>
        <div class="chev">
          <img
            src="https://img.favpng.com/0/19/7/computer-icons-arrow-symbol-png-favpng-SAduQqMHBMXgPFj2tvbXM446B.jpg"
            width="100%"
            height="100%"
          />
        </div>
      </div>

      <div class="lev" id = "clickmen">
        <div >MEN</div>
        <div class="chev">
          <img
            src="https://img.favpng.com/0/19/7/computer-icons-arrow-symbol-png-favpng-SAduQqMHBMXgPFj2tvbXM446B.jpg"
            width="100%"
            height="100%"
          />
        </div>
      </div>

      <div class="lev" id = "clickwomen" >
        <div >WOMEN</div>
        <div class="chev">
          <img
            src="https://img.favpng.com/0/19/7/computer-icons-arrow-symbol-png-favpng-SAduQqMHBMXgPFj2tvbXM446B.jpg"
            width="100%"
            height="100%"
          />
        </div>

      </div>
      <div class="lev" id = "clickkids">
        <div>KIDS</div>
        <div class="chev">
          <img
            src="https://img.favpng.com/0/19/7/computer-icons-arrow-symbol-png-favpng-SAduQqMHBMXgPFj2tvbXM446B.jpg"
            width="100%"
            height="100%"
          />
        </div>

      </div>
      <div class="lev" id = "clickoffers">
        <div >OFFERS</div>
        <div class="chev">
          <img
            src="https://img.favpng.com/0/19/7/computer-icons-arrow-symbol-png-favpng-SAduQqMHBMXgPFj2tvbXM446B.jpg"
            width="100%"
            height="100%"
          />
        </div>

      </div>
      <div class="lev" id = "clicksef">
        <div >SEPHORA</div>
        <div class="chev">
          <img
            src="https://img.favpng.com/0/19/7/computer-icons-arrow-symbol-png-favpng-SAduQqMHBMXgPFj2tvbXM446B.jpg"
            width="100%"
            height="100%"
          />
        </div>
      </div>
    </div>
   
      <div id="rig">

        <div>GAP</div>
        <div>U. S. Polo Assn.</div>
        <div>Flying Machine</div>
        <div>Aeropostale</div>
        <div>Sephora</div>
        <div>Ed Hardy</div>
        <div>Nautica</div>
        <div>True Blue</div>
        <div>Arrow</div>
        <div>Unlimited</div>
        <div>Arvind</div>
        <div>Sephora Collection</div>
        <div>Make Up For Ever</div>
        <div>Benefit</div>
        <div>The Children's Place</div>
      </div>

      <div id="rig1">

        <div>Clothing</div>
        <div>T-Shirts & Polos</div>
        <div>Casual Shirts</div>
        <div>Formal Shirts</div>
        <div>Jeans</div>
        <div>Ed Hardy</div>
        <div>Casual Trousers</div>
        <div>Formal Trousers</div>
        <div>Arrow</div>
        <div>Unlimited</div>
        <div>Arvind</div>
        <div>Casual</div>
        <div>Watches</div>
        <div>New In</div>
        <div>Ed Hardy</div>
        <div>Arrow</div>
        <div> Aéropostale</div>
        <div>New In Clothing</div>
        <div>New In Accessories</div>
        <div>New In Footwear</div>
      </div>


      <div id="rig2">

        <div>Clothing</div>
        <div>T-Shirts & Polos</div>
        <div>Casual Shirts</div>
        <div>Formal Shirts</div>
        <div>Jeans</div>
        <div>Ed Hardy</div>
        <div>Casual Trousers</div>
        <div>Formal Trousers</div>
        <div>Arrow</div>
        <div>Unlimited</div>
        <div>Arvind</div>
        <div>Casual</div>
        <div>Watches</div>
        <div>New In</div>
        <div>Ed Hardy</div>
        <div>Arrow</div>
        <div> Aéropostale</div>
        <div>New In Clothing</div>
        <div>New In Accessories</div>
        <div>New In Footwear</div>
        <div>Grooming</div>
        <div>Fragrances</div>
        <div>Belts</div>
        <div>Bags & Backpacks</div>
        <div>Watches</div>
        <div>Wallets</div>
        <div>Caps & Hats</div>
        <div>Sunglasses</div>
        <div>View All</div>
        <div>Brands</div>
        <div>True Blue</div>
        <div>U.S. Polo</div>
      </div>



      <div id="rig3">

        <div>Boys</div>
        <div>Polos & T-Shirts</div>
        <div>Jeans</div>
        <div>Trousers & Chinos</div>
        <div>Outerwear</div>
        <div>Shorts & 3/4ths</div>
        <div>Bodysuits</div>
        <div>Sets</div>
        <div>Arrow</div>
        <div>View All</div>
        <div>Tops & T Shirts</div>
        <div>Dresses</div>
        <div>Bodysuits</div>
        <div>Sets</div>
        <div>Ed Hardy</div>
        <div>Leggings & Jeggings</div>
        <div> Aéropostale</div>
        <div>Outerwear</div>
        <div>Shorts & Capris</div>
        <div>Skirts</div>
        <div>Jeans & Trousers</div>
        <div>Fragrances</div>
        <div>View All</div>
        <div>Bags & Backpacks</div>
        <div>Accessories</div>
        <div>Wallets</div>
        <div>Footwear</div>
        <div>Sunglasses</div>
        <div>View All</div>
        <div>Brands</div>
        <div>True Blue</div>
        <div>U.S. Polo</div>
      </div>


      <!--



















-->

      <div id="rig4">

        <div><h4> Men</h4></div>
        <div>1st time on discount</div>
        <div>Flat 30-50% off</div>
        <div>Holiday collection @ 50% off</div>
        <div>Work-wear @ 40% off</div>
        <div>Festive styles @ 50% off</div>
        <div><h4>Women</h4></div>
        <div>1st time on discount</div>
        <div>Arrow</div>
        <div>Flat 30- 50% off</div>
        <div>Clearance sale</div>
        <div>Everyday Casuals @ 50% off</div>
        <div>Work-wear @ 40% off</div>
        <div>Athleisure styles @ 40% off</div>
        <div><h4>Kids</h4></div>
        <div>1st time on discount</div>
        <div>Flat 30- 50% off</div>
        <div>Clearance sale</div>
        <div>Playtime outfits @ 50%</div>
        <div>Party styles @ 50%</div>
        <div>Relaxed outfits @ 40%</div>
       
      </div>

      <div id="rig5">

       <div><h4>Makeup</h4></div>
       <div>Face</div>
       <div>Eye</div>
       <div>Lip</div>
       <div> Cheek</div>
       <div>Nail & Accessories</div>
       <div>View All</div>
       <div><h4>Skincare</h4></div>
       <div>Shop By Concern</div>
       <div>Moisturizers</div>
       <div>Cleansers</div>
       <div>Skin Treatments</div>
       <div>Suncare</div>
       <div>View All</div>
       <div><h4>Fragrance</h4></div>
       <div>Women</div>
       <div>Men</div>
       <div>View All</div>
       <div>Bath & Body</div>
       <div>Bath & Shower</div>
       <div>Body Moisturizers</div>
       <div>Suncare</div>
       <div>Shampoo & Conditioner</div>
       <div>Hair Styling and Treatments</div>
       <div>View All</div>
       <div>Tools & Brushes</div>
       <div>Skincare Tools</div>
       <div>Makeup Brushes & Applicators</div>
       <div>Accessories</div>
       <div>View All</div>
       
      </div>



    </div>
    </div>


  
  </div>



    </div>




  <br /><br />

  <div id="sec">
    <div class="sep" style="margin-right: 22%">
      <input type="text" id="search" placeholder="🔍 Seach SEPHORA" />
    </div>
    <div class="sep1" id="seph" style="margin-right: 22%">S E P H O R A</div>
    <div class="sep11"><img src="/images/5.png" alt="" /></div>
    <div class="sep11"><a href = "bag.html"><img src="/images/6.png" /></a></div>
    <div id="log"><img src="/images/7.png" /></div>
  </div>

  <br /><br />

  <div id="list">
    <div>SALE</div>
    <div id="makeup">MAKEUP</div>
    <div id="skin">SKINCARE</div>
    <div id="fragnance">FRAGRANCE</div>
    <div id="haircare">HAIRCARE</div>
    <div id="brush">TOOLS & BRUSHES</div>
    <div id="brad">BRANDS</div>
  </div>

  <br />
  <div id="try">
    <div class="makeIn">
      <div class="bold">FACE</div>
      <div>Foundation</div>
      <div>BB & CC</div>
      <div>Concealer</div>
      <div>Face Primer</div>
      <div>Highlighter</div>
      <div>Face Brushes</div>
      <div>Makeup Palette</div>
    </div>
    <div class="makeIn">
      <div class="bold">EYE</div>
      <div>Eye Palettes</div>
      <div>Mascara</div>
      <div>Eyeliner</div>
      <div>Eyebrow</div>
      <div>Eyeshadow</div>
      <div>Eye Primer</div>
      <div>Eye Brushes</div>
      <div>Contact Lenses</div>
    </div>
    <div class="makeIn">
      <div class="bold">LIP</div>
      <div>Lipstick</div>
      <div>Lip Stain</div>
      <div>Lip Gloss</div>
      <div>Lip Liner</div>
      <div>Lip Balm & Treatment</div>
      <div>Lip Brushes</div>
    </div>
    <div class="makeIn">
      <div class="bold">CHEEK</div>
      <div>Blush</div>
      <div>Bronzer</div>
      <div>Highlighter</div>
      <div>Face Oils</div>
    </div>
    <div class="makeIn">
      <div class="bold">NAIL MAKEUP</div>
      <div>Nail Polish</div>
      <div>Nail Care</div>
      <div>Manicure & Pedicure Tools</div>
    </div>

    <div class="makeIn">
      <div class="bold">MAKEUP ACCESSORIES</div>
      <div>Tweezers & Eyebrow Tools</div>
      <div>Makeup Removers</div>
      <div>Sponges & Applicators</div>
      <div>Makeup Bags & Travel Cases</div>
    </div>

    <div class="makeIn">
      <div class="bold">VEGAN</div>
      <div>Eye</div>
      <div>Face</div>
    </div>
  </div>

  <div id="skincare">
    <div class="skinIN">
      <div class="bold">MOISTURIZERS</div>
      <div>Moisturizers</div>
      <div>Night Creams</div>
      <div>Mists & Essences</div>
      <div>BB & CC Creams</div>
    </div>
    <div class="skinIN">
      <div class="bold">CLEANSERS</div>
      <div>Face Wash & Cleansers</div>
      <div>Face Wipes</div>
      <div>Toners</div>
      <div>Hand Sanitizers</div>
    </div>
    <div class="skinIN">
      <div class="bold">TREATMENTS & HIGH TECH TOOLS</div>
      <div>Face Serums</div>
      <div>Cleansing Tools</div>
      <div>Eye Creams & Treatments</div>
    </div>
    <div class="skinIN">
      <div class="bold">MASKS</div>
      <div>Face Masks</div>
      <div>Sheet Masks</div>
      <div>Eye Masks</div>
      <div>Nose Masks & Strips</div>
      <div>Lip Masks</div>
      <div>Hair Masks</div>
      <div>Hand Masks</div>
      <div>Foot Masks</div>
    </div>
    <div class="skinIN">
      <div class="bold">BATH & SHOWER</div>
      <div>Body Wash and Shower Gel</div>
      <div>Scrub and Exfoliants</div>
      <div>Exfoliators</div>
    </div>

    <div class="skinIN">
      <div class="bold">BODY MOISTURIZERS</div>
      <div>Body Lotions & Body Oils</div>
      <div>Hand Cream & Foot Cream</div>
    </div>

    <div class="skinIN">
      <div class="bold">VEGAN</div>
      <div>Face Care</div>
    </div>
  </div>

  <div id="frag">
    <div class="fragIn" id="mLef">
      <div class="bold">WOMEN</div>
      <div>Perfume</div>
      <div>Mists and Deodorants</div>
    </div>

    <div class="fragIn">
      <div class="bold">MEN</div>
      <div>Perfume</div>
      <div>Body Sprays & Deodorant</div>
    </div>
  </div>

  <div id="hair">
    <div class="hairC" id="mLef">
      <div class="bold">SHAMPOO & CONDITIONER</div>
      <div>Shampoo</div>
      <div>Conditioner</div>
    </div>

    <div class="hairC">
      <div class="bold">HAIR STYLING & TREATMENTS</div>
      <div><a href = "hairSpray.html">Hair Spray & Styling Products</a></div>
      <div>Hair Oil</div>
      <div>Hair Masks</div>
      <div>Hair Clips</div>
    </div>
  </div>

  <div id="tools">
    <div class="tool" id="mLef">
      <div class="bold">BRUSHES</div>
      <div>Face Brushes</div>
      <div>Eye Brushes</div>
      <div>Lip Brushes</div>
    </div>

    <div class="tool">
      <div class="bold">TOOLS</div>
      <div>Sponges & Applicators</div>
      <div>Hair Clips</div>
      <div>Sharpeners</div>
      <div>Tweezers & Eyebrow Tools</div>
      <div>Eyelash Curlers</div>
      <div>Accessories</div>
      <div>Brush Cleaners</div>
    </div>

    <div class="tool">
      <div class="bold">VEGAN</div>
      <div>Face Brushes</div>
      <div>Eye Brushes</div>
    </div>
  </div>

  <div id="brands">
    <div class="brand">
      <div class="bold">TOP MAKEUP BRANDS</div>
      <div>Sephora Collection</div>
      <div>Lancôme</div>
      <div>Huda Beauty</div>
      <div>Benefit Cosmetics</div>
      <div>Anastasia Beverly Hills</div>
      <div>Bobbi Brown</div>
      <div>Smashbox</div>
      <div>Estee Lauder</div>
      <div>Nudestix</div>
      <div>MAC</div>
      <div>Make Up For Ever</div>
      <div>Guerlian</div>
    </div>

    <div class="brand">
      <div class="bold">TOP SKINCARE BRANDS</div>
      <div>Lancôme</div>
      <div>Caudalie</div>
      <div>Kora Organics</div>
      <div>Mario Badescu</div>
      <div>Foreo</div>
      <div>Pixi</div>
      <div>Shiseido</div>
      <div>Estee Lauder</div>
      <div>Clarins</div>
      <div>Elizabeth Arden</div>
      <div>Clinique</div>
      <div>Gallinee</div>
      <div>Wishful</div>
    </div>

    <div class="brand">
      <div class="bold">TOP FRAGRANCE BRANDS</div>
      <div>Tom Ford</div>
      <div>Hugo Boss</div>
      <div>Issye Miyake</div>
      <div>Ermenegildo Zegna</div>
      <div>Dolce & Gabbana</div>
      <div>Paco Rabanne</div>
      <div>Bvlgari</div>
      <div>Kayali</div>
      <div>Roberto Cavalli</div>
      <div>Versace</div>
      <div>Davidoff</div>
      <div>Calvin Klein</div>
      <div>Chopard</div>
      <div>Yves Saint Laurent</div>
    </div>

    <div class="brand">
      <div class="bold">NEW IN</div>
      <div>Juice Beauty</div>
      <div>Abhati Suisse</div>
      <div>Kora Organics</div>
      <div>Caudalie</div>
      <div>Mario Badescu</div>
      <div>Moroccanoil</div>
      <div>Tiffany & Co</div>
      <div>Natasha Denona</div>
      <div>Lancôme</div>
    </div>
    <div class="brand">
      <div class="bold">BRANDS A - Z</div>
    </div>
  </div>
  
  
  
  
  
  
  
  <div id="logIn">

  <div id = "cros">✖</div>

    <h1 style="text-align: center;">LOGIN</h1>
    <div class = "upText" >Enter your Username</div>

    <div class="logInP">
    <input type="text" id = "yrUserName" >
  </div>

  <br>
  <div class = "upText" >Enter your Password</div>

  <div class="logInP">
  <input type="password"  id = "yrPassword">
</div>

<div class = "upText"></div>
  <br><br><br>
<div class="logInP">
<button class = "contP" id = "cntnuu">CONTINUE</button>
</div>
<br><br><br>

  <div style="text-align: center;">Or</div>

<div class="logInP">
<button class="contP" id = "regii" >Register</button> 
</div>
</div>

    <div id = "regIn">
      <div id = "ciross">✖</div>
      <div id = "regInDiv">
        <br>
      <div class = "grText" >Name</div>
      <input type="text"  id = "namer">
      <br><br>
      <div class = "grText" >Phone</div>
      <input type="number" id = "phoner" >
      <br><br>
      <div class = "grText" >Email</div>
      <input type="email" id = "mailer" >
      <br><br>
      <div class = "grText" >Password</div>
      <input type="password" id = "passer" >
      <br><br>
      <button class = "selfR" id = "rekister">REGISTER</button>
        <br><br>
        <hr>
        <br>
        <button class = "selfR" id = "logee">LOGIN</button>

    </div>

    </div>
  `

  
}

export default navbar;