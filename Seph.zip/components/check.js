function check(){

    return ` <div class="wide">S E P H O R A</div>
    <div class="wide" style="background-color: #0092df; color: white">
      <span>MY BAG</span><span id="nim"></span>
    </div>
    <br />
    <div id="maiNN">
      <div id="ulta"></div>
      <div id="sidha">
      
       

        
       
        <br />
        <div id="bill">
          <div class="bory">OVERVIEW</div>

          <div class="spbw">
            <div>Subtotal</div>
            <div id="trotal1"></div>
          </div>

          <div class="spbw">
            <div>Discount</div>
            <div>-Rs.0</div>
          </div>

          <div class="spbw">
            <div>GST</div>
            <div>Rs.0</div>
          </div>

          <div class="spbw">
            <div>Delivery Charges ❕</div>
            <div>Rs.0</div>
          </div>
          <hr style="font-weight: bold" />
          <br />
          <div class="bory">
            <div>Total</div>
            <div id="trotal2"></div>
          </div>
        </div>
        <br />
        <div style="display: flex; justify-content: center">
          <button id="check_out">CONTINUE</button>
        </div>
        <br />
       

        <br />

        <div style="margin: auto; width: 80%; height: 90px">
          <img
            src="https://static.nnnow.com/mybag_offer_banner.jpg"
            width="100%"
            height="100%"
          />
        </div>
      </div>
    </div>`


}

export default check;